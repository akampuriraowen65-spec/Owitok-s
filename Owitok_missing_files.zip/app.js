const $=s=>document.querySelector(s);const $$=s=>document.querySelectorAll(s);
const DB="owitok_v1";let db;let currentCommentsId=null;
const state={videos:[],likes:new Set(JSON.parse(localStorage.getItem("ow_likes")||"[]")),saves:new Set(JSON.parse(localStorage.getItem("ow_saves")||"[]")),comments:JSON.parse(localStorage.getItem("ow_comments")||"{}")};
function toast(t){const e=$("#toast");e.textContent=t;e.style.display="block";setTimeout(()=>e.style.display="none",1800)}
function openDB(){return new Promise((res,rej)=>{const r=indexedDB.open(DB,1);r.onupgradeneeded=()=>r.result.createObjectStore("videos",{keyPath:"id"});r.onsuccess=()=>{db=r.result;res()};r.onerror=()=>rej(r.error)})}
function saveVideo(v){return new Promise((res,rej)=>{const tx=db.transaction("videos","readwrite");tx.objectStore("videos").put(v);tx.oncomplete=res;tx.onerror=()=>rej(tx.error)})}
function loadVideos(){return new Promise((res,rej)=>{const r=db.transaction("videos").objectStore("videos").getAll();r.onsuccess=()=>res(r.result||[]);r.onerror=()=>rej(r.error)})}
function persist(){localStorage.setItem("ow_likes",JSON.stringify([...state.likes]));localStorage.setItem("ow_saves",JSON.stringify([...state.saves]));localStorage.setItem("ow_comments",JSON.stringify(state.comments))}
function showScreen(id){$$(".screen").forEach(x=>x.classList.remove("active"));$("#"+id).classList.add("active");$$(".nav").forEach(x=>x.classList.toggle("active",x.dataset.screen===id))}
function renderFeed(){const list=$("#feed-list");list.innerHTML="";if(!state.videos.length){list.innerHTML='<div class="feed-card"><div class="empty-card">No videos yet.<br>Upload your first video from ＋.</div></div>';return}
state.videos.forEach(v=>{const c=document.createElement("article");c.className="feed-card";c.innerHTML=`<video src="${v.url}" loop playsinline preload="metadata"></video><div class="video-overlay"><div class="meta"><b>@${escapeHtml(v.username||"owitok_user")}</b><p>${escapeHtml(v.caption||"")}</p></div><div class="actions"><button class="action like">♥</button><button class="action comment">💬</button><button class="action save">🔖</button><button class="action share">↗</button></div></div>`;
const vid=c.querySelector("video");vid.addEventListener("click",()=>vid.paused?vid.play():vid.pause());
c.querySelector(".like").onclick=()=>{state.likes.has(v.id)?state.likes.delete(v.id):state.likes.add(v.id);persist();toast(state.likes.has(v.id)?"Liked":"Unliked")};
c.querySelector(".save").onclick=()=>{state.saves.has(v.id)?state.saves.delete(v.id):state.saves.add(v.id);persist();toast(state.saves.has(v.id)?"Saved":"Removed from saves")};
c.querySelector(".comment").onclick=()=>openComments(v.id);
c.querySelector(".share").onclick=()=>shareVideo(v);
list.appendChild(c)});
const obs=new IntersectionObserver(es=>es.forEach(e=>{const v=e.target;if(e.isIntersecting)v.play().catch(()=>{});else v.pause()}),{threshold:.65});list.querySelectorAll("video").forEach(v=>obs.observe(v))}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function openComments(id){currentCommentsId=id;$("#comments-modal").hidden=false;renderComments()}
function renderComments(){const arr=state.comments[currentCommentsId]||[];$("#comments-list").innerHTML=arr.length?arr.map(x=>`<div class="comment"><b>@owitok_user</b> ${escapeHtml(x)}</div>`).join(""):'<p class="muted">No comments yet.</p>'}
function shareVideo(v){if(navigator.share)navigator.share({title:"Owitok video",text:v.caption||"Check this video on Owitok"}).catch(()=>{});else{navigator.clipboard?.writeText(location.href);toast("Link copied")}}
function search(q){const out=$("#search-results");const term=q.trim().toLowerCase();const hits=state.videos.filter(v=>(v.caption||"").toLowerCase().includes(term)||(v.username||"").toLowerCase().includes(term));out.innerHTML=hits.length?hits.map(v=>`<div class="empty-card">@${escapeHtml(v.username||"owitok_user")} — ${escapeHtml(v.caption||"Video")}</div>`).join(""):'<div class="empty-card">No matching local videos.</div>'}
async function upload(file){const id=crypto.randomUUID();const url=URL.createObjectURL(file);const v={id,url,name:file.name,username:"owitok_user",caption:"",createdAt:Date.now()};await saveVideo(v);state.videos.unshift(v);renderFeed();$("#video-count").textContent=state.videos.length;showScreen("feed-screen");toast("Video added to this device")}
$$(".nav").forEach(b=>b.onclick=()=>showScreen(b.dataset.screen));
$("#open-search").onclick=()=>showScreen("search-screen");
$$(".tab").forEach(b=>b.onclick=()=>{toast(b.dataset.tab==="following"?"Following will use real accounts after the backend is added.":"For You");});
$("#video-picker").onchange=e=>{if(e.target.files[0])upload(e.target.files[0])};
$("#close-comments").onclick=()=>$("#comments-modal").hidden=true;
$("#send-comment").onclick=()=>{const x=$("#comment-input").value.trim();if(!x)return;(state.comments[currentCommentsId]??=[]).push(x);$("#comment-input").value="";persist();renderComments()};
$("#search-input").oninput=e=>search(e.target.value);
$("#edit-profile").onclick=()=>{const n=prompt("Username",localStorage.getItem("ow_name")||"owitok_user");if(n){localStorage.setItem("ow_name",n);$("#profile-handle").textContent="@"+n}};
$("#camera-btn").onclick=async()=>{try{const s=await navigator.mediaDevices.getUserMedia({video:true,audio:true});const v=$("#camera-preview");v.hidden=false;v.srcObject=s;toast("Camera preview started")}catch(e){toast("Camera permission was not granted")}};
$("#data-saver").onchange=e=>localStorage.setItem("ow_data",e.target.checked);
$("#dark-mode").onchange=e=>document.body.classList.toggle("light",!e.target.checked);
(async()=>{await openDB();state.videos=await loadVideos();$("#video-count").textContent=state.videos.length;$("#profile-handle").textContent="@"+(localStorage.getItem("ow_name")||"owitok_user");renderFeed();setTimeout(()=>$("#splash").style.display="none",700);if("serviceWorker"in navigator)navigator.serviceWorker.register("service-worker.js").catch(()=>{})})()
